I'm not sure exactly what to include in here...

all the project files are included and the data set is titled tba-data-formatted.txt
take a look at my scraping code at: https://github.com/Ivendrakeo/CS4981-TBA-Scraper
	Hopefully I will have created instructions on how to use it there.
	(WARNING: takes ~2hrs to run the first time with no local cache...) *im including tba-data.txt if you wanted to use the scraper and have the major cache
Also the API I scraped was multiple categories from TBA-APIv3: https://www.thebluealliance.com/apidocs/v3

Thanks for the advice and help verifying the project direction!

